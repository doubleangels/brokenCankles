# BrokenCankles

A modpack that will help you not break your cankles.

The modpack can be found [here](https://thunderstore.io/c/lethal-company/p/BrokenCankles/BrokenCankles/).

## Changelog

### v1.0.0

- Initial release of modpack

### v1.0.1

- Added more suits.
- README changes.

### v1.0.2

- Added Github repository.

### v1.0.3

- Added link to modpack listing in README.
